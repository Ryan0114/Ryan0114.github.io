import cv2
import numpy as np
import chess_module as cm
import HandTrackingModule
import time

cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
cap.set(3, 1280)  # 1280
cap.set(4, 720)  # 720
cap.set(cv2.CAP_PROP_FPS, 60)

blank = np.zeros((720, 1280, 3), dtype='uint8') + 255

top_left_x = 600
top_left_y = 5
bottom_right_x = 1160
bottom_right_y = 565
grid_size = 70

pick = False

detector = HandTrackingModule.HandDetector(max_hand=1, detection_confidence=0.5)

cm.grid_color_init()

p_time = 0
while True:
    success, img = cap.read()
    img = cv2.flip(img, 1)
    img = detector.find_hands(img)
    lm_list = detector.find_position(img, draw=False)

    img = cm.draw_board(img)
    if len(lm_list) != 0:
        h_x, h_y = lm_list[8][1], lm_list[8][2]
        b_x, b_y = int((h_x - top_left_x) / grid_size), int((h_y - top_left_y) / grid_size)

        up_down_list = detector.hand_on()
        cm.en_passant(b_x, b_y)

        if up_down_list == [0, 1, 0, 0, 0] and pick:
            pick = False
            cm.highlight = False
            cm.drop_piece(b_x, b_y)
            cm.grid_color_init()
        elif up_down_list == [0, 1, 1, 0, 0]:
            if top_left_x < h_x < top_left_x + 8*grid_size and top_left_y < h_y < top_left_y + 8*grid_size:
                if not cm.highlight:
                    cm.show_valid_movement(b_x, b_y)
                img, pick = cm.move_piece(img, b_x, b_y, h_x, h_y, pick)
            elif pick:
                cm.board[cm.original_pos_y][cm.original_pos_x] = cm.picked_piece
                cm.grid_color_init()
                # pick = False
                cm.highlight = False

    c_time = time.time()
    fps = 1/(c_time-p_time)
    p_time = c_time
    cv2.putText(img, f'FPS: {int(fps)}', (10, 30), cv2.FONT_HERSHEY_PLAIN, 2, (0, 255, 0), 3)

    img = cm.draw_piece(img)
    # img = cv2.bitwise_and(img, blank)
    if len(lm_list) != 0:
        cv2.circle(img, (lm_list[8][1], lm_list[8][2]), 15, (0, 0, 255), -1)

    cv2.putText(img, "press Q to quit", (10, 710), cv2.FONT_HERSHEY_PLAIN, 2, (0, 255, 0), 3)
    cv2.imshow("Image", img)
    if cv2.waitKey(1) & 0xFF == ord("q"):
        break
