import cv2 as cv
import numpy as np

# WHITE(FIRST)  1
wP = cv.imread('chess_picture\\wP.png')  # PAWN    1
wR = cv.imread('chess_picture\\wR.png')  # ROOK    2
wN = cv.imread('chess_picture\\wN.png')  # KNIGHT  3
wB = cv.imread('chess_picture\\wB.png')  # BISHOP  4
wQ = cv.imread('chess_picture\\wQ.png')  # QUEEN   5
wK = cv.imread('chess_picture\\wK.png')  # KING    6
# BLACK
bP = cv.imread('chess_picture\\bp.png')  # PAWN    7
bR = cv.imread('chess_picture\\bR.png')  # ROOK    8
bN = cv.imread('chess_picture\\bN.png')  # KNIGHT  9
bB = cv.imread('chess_picture\\bB.png')  # BISHOP  10
bQ = cv.imread('chess_picture\\bQ.png')  # QUEEN   11
bK = cv.imread('chess_picture\\bK.png')  # KING    12

piece = [wP, wR, wN, wB, wQ, wK, bP, bR, bN, bB, bQ, bK]
board = [[8, 9, 10, 11, 12, 10, 9, 8],
         [7, 7, 7, 7, 7, 7, 7, 7],
         [0, 0, 0, 0, 0, 0, 0, 0],
         [0, 0, 0, 0, 0, 0, 0, 0],
         [0, 0, 0, 0, 0, 0, 0, 0],
         [0, 0, 0, 0, 0, 0, 0, 0],
         [1, 1, 1, 1, 1, 1, 1, 1],
         [2, 3, 4, 5, 6, 4, 3, 2]]
grid_size = 70
grid_color = [[(0, 0, 0) for i in range(8)] for j in range(8)]

white = True

top_left_x = 600
top_left_y = 5
bottom_right_x = 1160
bottom_right_y = 565
blank = np.zeros((720, 1280, 3), dtype="uint8")

picked_piece = -1

original_pos_x, original_pos_y = -1, -1

white_pieces = [1, 2, 3, 4, 5, 6]
black_pieces = [7, 8, 9, 10, 11, 12]

blue = (255, 223, 215)
red = (0, 0, 255)

highlight = False

can_en_passant = False
en_passant_li = []


def grid_color_init():
    global grid_color
    for i in range(0, 8):
        for j in range(0, 8):
            if (i + j) % 2 == 1:
                grid_color[i][j] = (153, 200, 229)
            else:
                grid_color[i][j] = (255, 255, 255)


def draw_board(blank_chess_board):
    cv.line(blank_chess_board, (top_left_x, top_left_y), (top_left_x, top_left_y + grid_size * 8), (0, 0, 0), 3)
    cv.line(blank_chess_board, (top_left_x, top_left_y), (top_left_x + grid_size * 8, top_left_y), (0, 0, 0), 3)
    cv.line(blank_chess_board, (top_left_x + grid_size * 8, top_left_y),
            (top_left_x + grid_size * 8, top_left_y + grid_size * 8),
            (0, 0, 0), 3)
    cv.line(blank_chess_board, (top_left_x, top_left_y + grid_size * 8),
            (top_left_x + grid_size * 8, top_left_y + grid_size * 8),
            (0, 0, 0), 3)
    for i in range(0, 8):
        for j in range(0, 8):
            if (i + j) % 2 == 1:
                blank_chess_board[top_left_y + i * grid_size:top_left_y + (i + 1) * grid_size,
                top_left_x + j * grid_size:top_left_x + (j + 1) * grid_size] = grid_color[j][i]
            else:
                blank_chess_board[top_left_y + i * grid_size:top_left_y + (i + 1) * grid_size,
                top_left_x + j * grid_size:top_left_x + (j + 1) * grid_size] = grid_color[j][i]
    for i in range(0, 9):
        cv.line(blank_chess_board, (top_left_x + i*grid_size, top_left_y),
                (top_left_x + i*grid_size, top_left_y+8*grid_size), (0, 0, 0), 1)
        cv.line(blank_chess_board, (top_left_x, top_left_y+i*grid_size),
                (top_left_x + 8*grid_size, top_left_y+i*grid_size), (0, 0, 0), 1)
    return blank_chess_board


def draw_piece(img):
    blank_tem = np.zeros((720, 1280, 3), dtype="uint8") + 255
    for i in range(0, 8):
        for j in range(0, 8):
            if board[i][j] != 0:
                chess_img = piece[board[i][j] - 1]
                blank_tem[top_left_y + i * grid_size + 5:top_left_y + (i + 1) * grid_size - 5,
                top_left_x + j * grid_size + 5:top_left_x + (j + 1) * grid_size - 5] = chess_img
                img = cv.bitwise_and(blank_tem, img)
    return img


def move_piece(img, x, y, h_x, h_y, pick):
    blank_tem = np.zeros((720, 1280, 3), dtype="uint8") + 255
    global picked_piece, original_pos_x, original_pos_y
    if not pick and board[y][x] != 0:
        if original_pos_x != x and original_pos_y != y:
            original_pos_x = x
            original_pos_y = y
        picked_piece = board[y][x]
        board[y][x] = 0
        pick = True
    if pick:
        if picked_piece == 1 and original_pos_x != x and board[y][x] == 1:
            board[original_pos_y][x] = 0
        chess_img = piece[picked_piece - 1]
        blank_tem[h_y + 5:h_y + grid_size - 5, h_x + 5:h_x + grid_size - 5] = chess_img
        img = cv.bitwise_and(blank_tem, img)
    return img, pick


def drop_piece(x, y):
    if 0 <= x <= 7 and 0 <= y <= 7:
        if is_valid(x, y):
            board[y][x] = picked_piece
        else:
            board[original_pos_y][original_pos_x] = picked_piece
    else:
        board[original_pos_y][original_pos_x] = picked_piece


def show_valid_movement(x, y):
    global highlight
    en_passant(x, y)
    if 1 <= board[y][x] <= 12:
        grid_color[x][y] = blue
    if board[y][x] == 1:
        if y == 6:
            if board[y-1][x] == 0:
                grid_color[x][y-1] = blue
                if board[y-2][x] == 0:
                    grid_color[x][y-2] = blue
        else:
            global en_passant_li
            if y > 0 and board[y-1][x] == 0:
                grid_color[x][y-1] = blue
            if y == 3 and can_en_passant:
                en_passant_li = [[x-1, y-1], [x+1, y-1]]
                if board[y][x-1] == 7:
                    grid_color[x-1][y-1] = red
                if board[y][x+1] == 7:
                    grid_color[x+1][y-1] = red
        if board[y-1][x-1] in black_pieces:
            grid_color[x-1][y-1] = red
        if board[y-1][x+1] in black_pieces:
            grid_color[x+1][y-1] = red
        highlight = True
    if board[y][x] == 7:
        if y == 1:
            if board[y+1][x] == 0:
                grid_color[x][y+1] = blue
                if board[y+2][x] == 0:
                    grid_color[x][y+2] = blue
        else:
            if y < 7 and board[y+1][x] == 0:
                grid_color[x][y+1] = blue
        if 0 <= y+1 < 8 and 0 <= x+1 < 8:
            if board[y+1][x+1] in white_pieces:
                grid_color[x+1][y+1] = red
        if 0 <= y+1 < 8 and 0 <= x-1 < 8:
            if board[y+1][x-1] in white_pieces:
                grid_color[x-1][y+1] = red
        highlight = True
    if board[y][x] == 2 or board[y][x] == 8:
        if board[y][x] == 2:
            for i in range(1, 8):
                if 0 <= y-i <= 7 and 0 <= x <= 7:
                    if board[y-i][x] not in white_pieces and board[y-i][x] not in black_pieces:
                        grid_color[x][y-i] = blue
                    elif board[y-i][x] in white_pieces:
                        break
                    else:
                        grid_color[x][y-i] = red
                        break
            for i in range(1, 8):
                if 0 <= x+i <= 7 and 0 <= y <= 7:
                    if board[y][x+i] not in white_pieces and board[y][x+i] not in black_pieces:
                        grid_color[x+i][y] = blue
                    elif board[y][x+i] in white_pieces:
                        break
                    else:
                        grid_color[x+i][y] = red
                        break
            for i in range(1, 8):
                if 0 <= x-i <= 7 and 0 <= y <= 7:
                    if board[y][x-i] not in white_pieces and board[y][x-i] not in black_pieces:
                        grid_color[x-i][y] = blue
                    elif board[y][x-i] in white_pieces:
                        break
                    else:
                        grid_color[x-i][y] = red
                        break
            for i in range(1, 8):
                if 0 <= y+i <= 7 and 0 <= x <= 7:
                    if board[y+i][x] not in white_pieces and board[y+i][x] not in black_pieces:
                        grid_color[x][y+i] = blue
                    elif board[y+i][x] in white_pieces:
                        break
                    else:
                        grid_color[x][y+i] = red
                        break
        if board[y][x] == 8:
            for i in range(1, 8):
                if 0 <= y - i <= 7 and 0 <= x <= 7:
                    if board[y - i][x] not in white_pieces and board[y - i][x] not in black_pieces:
                        grid_color[x][y - i] = blue
                    elif board[y - i][x] in black_pieces:
                        break
                    else:
                        grid_color[x][y - i] = red
                        break
            for i in range(1, 8):
                if 0 <= x + i <= 7 and 0 <= y <= 7:
                    if board[y][x + i] not in white_pieces and board[y][x + i] not in black_pieces:
                        grid_color[x + i][y] = blue
                    elif board[y][x + i] in black_pieces:
                        break
                    else:
                        grid_color[x + i][y] = red
                        break
            for i in range(1, 8):
                if 0 <= x - i <= 7 and 0 <= y <= 7:
                    if board[y][x - i] not in white_pieces and board[y][x - i] not in black_pieces:
                        grid_color[x - i][y] = blue
                    elif board[y][x - i] in black_pieces:
                        break
                    else:
                        grid_color[x - i][y] = red
                        break
            for i in range(1, 8):
                if 0 <= y + i <= 7 and 0 <= x <= 7:
                    if board[y + i][x] not in white_pieces and board[y + i][x] not in black_pieces:
                        grid_color[x][y + i] = blue
                    elif board[y + i][x] in black_pieces:
                        break
                    else:
                        grid_color[x][y + i] = red
                        break
        highlight = True
    if board[y][x] == 3 or board[y][x] == 9:
        if board[y][x] == 3:
            for i in [1, -1]:
                for j in [2, -2]:
                    if 0 <= x-i < 8 and 0 <= y-j < 8:
                        if board[y-j][x-i] == 0:
                            grid_color[x-i][y-j] = blue
                        elif board[y-j][x-i] in black_pieces:
                            grid_color[x-i][y-j] = red
                    if 0 <= x-j < 8 and 0 <= y-i < 8:
                        if board[y-i][x-j] == 0:
                            grid_color[x-j][y-i] = blue
                        elif board[y-i][x-j] in black_pieces:
                            grid_color[x-j][y-i] = red
        if board[y][x] == 9:
            for i in [1, -1]:
                for j in [2, -2]:
                    if 0 <= x-i < 8 and 0 <= y-j < 8:
                        if board[y-j][x-i] == 0:
                            grid_color[x-i][y-j] = blue
                        elif board[y-j][x-i] in white_pieces:
                            grid_color[x-i][y-j] = red
                    if 0 <= x-j < 8 and 0 <= y-i < 8:
                        if board[y-i][x-j] == 0:
                            grid_color[x-j][y-i] = blue
                        elif board[y-i][x-j] in white_pieces:
                            grid_color[x-j][y-i] = red
        highlight = True
    if board[y][x] == 4 or board[y][x] == 10:
        if board[y][x] == 4:
            for i in range(1, 8):
                if 0 <= x - i < 8 and 0 <= y - i < 8:
                    if board[y - i][x - i] == 0:
                        grid_color[x - i][y - i] = blue
                    elif board[y - i][x - i] in black_pieces:
                        grid_color[x - i][y - i] = red
                        break
                    else:
                        break
            for i in range(1, 8):
                if 0 <= x - i < 8 and 0 <= y + i < 8:
                    if board[y + i][x - i] == 0:
                        grid_color[x - i][y + i] = blue
                    elif grid_color[y + i][x - i] in black_pieces:
                        grid_color[x - i][y + i] = red
                        break
                    else:
                        break
            for i in range(1, 8):
                if 0 <= x + i < 8 and 0 <= y - i < 8:
                    if board[y - i][x + i] == 0:
                        grid_color[x + i][y - i] = blue
                    elif board[y - i][x + i] in black_pieces:
                        grid_color[x + i][y - i] = red
                        break
                    else:
                        break
            for i in range(1, 8):
                if 0 <= x + i < 8 and 0 <= y + i < 8:
                    if board[y + i][x + i] == 0:
                        grid_color[x + i][y + i] = blue
                    elif board[y + i][x + i] in black_pieces:
                        grid_color[x + i][y + i] = red
                        break
                    else:
                        break
        if board[y][x] == 10:
            for i in range(1, 8):
                if 0 <= x - i < 8 and 0 <= y - i < 8:
                    if board[y - i][x - i] == 0:
                        grid_color[x - i][y - i] = blue
                    elif board[y - i][x - i] in white_pieces:
                        grid_color[x - i][y - i] = red
                        break
                    else:
                        break
            for i in range(1, 8):
                if 0 <= x - i < 8 and 0 <= y + i < 8:
                    if board[y + i][x - i] == 0:
                        grid_color[x - i][y + i] = blue
                    elif grid_color[y + i][x - i] in white_pieces:
                        grid_color[x - i][y + i] = red
                        break
                    else:
                        break
            for i in range(1, 8):
                if 0 <= x + i < 8 and 0 <= y - i < 8:
                    if board[y - i][x + i] == 0:
                        grid_color[x + i][y - i] = blue
                    elif board[y - i][x + i] in white_pieces:
                        grid_color[x + i][y - i] = red
                        break
                    else:
                        break
            for i in range(1, 8):
                if 0 <= x + i < 8 and 0 <= y + i < 8:
                    if board[y + i][x + i] == 0:
                        grid_color[x + i][y + i] = blue
                    elif board[y + i][x + i] in white_pieces:
                        grid_color[x + i][y + i] = red
                        break
                    else:
                        break
        highlight = True
    if board[y][x] == 5 or board[y][x] == 11:
        if board[y][x] == 5:
            for i in range(1, 8):
                if 0 <= x-i < 8 and 0 <= y-i < 8:
                    if board[y-i][x-i] == 0:
                        grid_color[x-i][y-i] = blue
                    elif board[y-i][x-i] in black_pieces:
                        grid_color[x-i][y-i] = red
                        break
                    else:
                        break
            for i in range(1, 8):
                if 0 <= x-i < 8 and 0 <= y+i < 8:
                    if board[y+i][x-i] == 0:
                        grid_color[x-i][y+i] = blue
                    elif board[y+i][x-i] in black_pieces:
                        grid_color[x-i][y+i] = red
                        break
                    else:
                        break
            for i in range(1, 8):
                if 0 <= x+i < 8 and 0 <= y-i < 8:
                    if board[y-i][x+i] == 0:
                        grid_color[x+i][y-i] = blue
                    elif board[y-i][x+i] in black_pieces:
                        grid_color[x+i][y-i] = red
                        break
                    else:
                        break
            for i in range(1, 8):
                if 0 <= x+i < 8 and 0 <= y+i < 8:
                    if board[y+i][x+i] == 0:
                        grid_color[x+i][y+i] = blue
                    elif board[y+i][x+i] in black_pieces:
                        grid_color[x+i][y+i] = red
                        break
                    else:
                        break
            for i in range(1, 8):
                if 0 <= y-i <= 7 and 0 <= x <= 7:
                    if board[y-i][x] not in white_pieces and board[y-i][x] not in black_pieces:
                        grid_color[x][y-i] = blue
                    elif board[y-i][x] in white_pieces:
                        break
                    else:
                        grid_color[x][y-i] = red
                        break
            for i in range(1, 8):
                if 0 <= x+i <= 7 and 0 <= y <= 7:
                    if board[y][x+i] not in white_pieces and board[y][x+i] not in black_pieces:
                        grid_color[x+i][y] = blue
                    elif board[y][x+i] in white_pieces:
                        break
                    else:
                        grid_color[x+i][y] = red
                        break
            for i in range(1, 8):
                if 0 <= x-i <= 7 and 0 <= y <= 7:
                    if board[y][x-i] not in white_pieces and board[y][x-i] not in black_pieces:
                        grid_color[x-i][y] = blue
                    elif board[y][x-i] in white_pieces:
                        break
                    else:
                        grid_color[x-i][y] = red
                        break
            for i in range(1, 8):
                if 0 <= y+i <= 7 and 0 <= x <= 7:
                    if board[y+i][x] not in white_pieces and board[y+i][x] not in black_pieces:
                        grid_color[x][y+i] = blue
                    elif board[y+i][x] in white_pieces:
                        break
                    else:
                        grid_color[x][y+i] = red
                        break
        if board[y][x] == 11:
            for i in range(1, 8):
                if 0 <= x-i < 8 and 0 <= y-i < 8:
                    if board[y-i][x-i] == 0:
                        grid_color[x-i][y-i] = blue
                    elif board[y-i][x-i] in white_pieces:
                        grid_color[x-i][y-i] = red
                        break
                    else:
                        break
            for i in range(1, 8):
                if 0 <= x-i < 8 and 0 <= y+i < 8:
                    if board[y+i][x-i] == 0:
                        grid_color[x-i][y+i] = blue
                    elif board[y+i][x-i] in white_pieces:
                        grid_color[x-i][y+i] = red
                        break
                    else:
                        break
            for i in range(1, 8):
                if 0 <= x+i < 8 and 0 <= y-i < 8:
                    if board[y-i][x+i] == 0:
                        grid_color[x+i][y-i] = blue
                    elif board[y-i][x+i] in white_pieces:
                        grid_color[x+i][y-i] = red
                        break
                    else:
                        break
            for i in range(1, 8):
                if 0 <= x+i < 8 and 0 <= y+i < 8:
                    if board[y+i][x+i] == 0:
                        grid_color[x+i][y+i] = blue
                    elif board[y+i][x+i] in white_pieces:
                        grid_color[x+i][y+i] = red
                        break
                    else:
                        break
            for i in range(1, 8):
                if 0 <= y-i <= 7 and 0 <= x <= 7:
                    if board[y-i][x] not in white_pieces and board[y-i][x] not in black_pieces:
                        grid_color[x][y-i] = blue
                    elif board[y-i][x] in black_pieces:
                        break
                    else:
                        grid_color[x][y-i] = red
                        break
            for i in range(1, 8):
                if 0 <= x+i <= 7 and 0 <= y <= 7:
                    if board[y][x+i] not in white_pieces and board[y][x+i] not in black_pieces:
                        grid_color[x+i][y] = blue
                    elif board[y][x+i] in black_pieces:
                        break
                    else:
                        grid_color[x+i][y] = red
                        break
            for i in range(1, 8):
                if 0 <= x-i <= 7 and 0 <= y <= 7:
                    if board[y][x-i] not in white_pieces and board[y][x-i] not in black_pieces:
                        grid_color[x-i][y] = blue
                    elif board[y][x-i] in black_pieces:
                        break
                    else:
                        grid_color[x-i][y] = red
                        break
            for i in range(1, 8):
                if 0 <= y+i <= 7 and 0 <= x <= 7:
                    if board[y+i][x] not in white_pieces and board[y+i][x] not in black_pieces:
                        grid_color[x][y+i] = blue
                    elif board[y+i][x] in black_pieces:
                        break
                    else:
                        grid_color[x][y+i] = red
                        break
        highlight = True
    if board[y][x] == 6 or board[y][x] == 12:
        if board[y][x] == 6:
            for i in [1, 0, -1]:
                for j in [1, 0, -1]:
                    if 0 <= x + i < 8 and 0 <= y + j < 8:
                        if board[y+j][x+i] == 0:
                            grid_color[x + i][y + j] = blue
                        elif board[y+j][x+i] in black_pieces:
                            grid_color[x+i][y+j] = red
        if board[y][x] == 12:
            for i in [1, 0, -1]:
                for j in [1, 0, -1]:
                    if 0 <= x + i < 8 and 0 <= y + j < 8:
                        if board[y + j][x + i] == 0:
                            grid_color[x + i][y + j] = blue
                        elif board[y+j][x+i] in white_pieces:
                            grid_color[x + i][y + j] = red
        highlight = True


def is_valid(x, y):
    if grid_color[x][y] == blue or grid_color[x][y] == red:
        if ((board[y][x] >= 7 or board[y][x] == 0) and 0 < picked_piece <= 6) or\
                (0 <= board[y][x] <= 6 and picked_piece >= 7):
            return True
        else:
            return False
    else:
        return False


def is_enemy():
    pass


def castle():
    pass


def en_passant(x, y):
    global can_en_passant, en_passant_li
    if board[y][x] == 1:
        if original_pos_y == 6 and y == 4:
            print("ori: ", original_pos_y, "y:", y)
            en_passant_li = [(x+1, y), (x-1, y)]
            can_en_passant = True
    elif board[y][x] == 7:
        if original_pos_y == 1 and y == 3:
            print("ori: ", original_pos_y, "y:", y)
            en_passant_li = [(x+1, y), (x-1, y)]
            can_en_passant = True
    else:
        can_en_passant = False
        en_passant_li = []


def promote():
    pass


def checkmate():
    pass

